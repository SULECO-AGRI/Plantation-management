export { FeatureDetailPanel } from './FeatureDetailPanel'
